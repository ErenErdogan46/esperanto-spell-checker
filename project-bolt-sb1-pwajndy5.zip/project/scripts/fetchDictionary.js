import fs from 'fs/promises';
import fetch from 'node-fetch';
import { fileURLToPath } from 'url';
import { dirname, join } from 'path';

const __filename = fileURLToPath(import.meta.url);
const __dirname = dirname(__filename);

async function fetchAndProcessDictionary() {
  console.log('Fetching Esperanto dictionary data...');
  
  try {
    // Fetch the dictionary data from a reliable GitHub source
    const response = await fetch('https://raw.githubusercontent.com/hermitdave/FrequencyWords/master/content/2018/eo/eo_full.txt');
    if (!response.ok) {
      throw new Error(`HTTP error! status: ${response.status}`);
    }
    const text = await response.text();
    
    // Process the words to create our dictionary format
    const dictionary = new Set();
    const roots = new Set();
    
    // Each line contains: word frequency
    text.split('\n').forEach(line => {
      const [word] = line.split(' ');
      if (word && word.length > 1) {
        // Clean the word and add it to the dictionary
        const cleanWord = word.toLowerCase().trim();
        if (cleanWord) {
          dictionary.add(cleanWord);
          
          // Try to identify the root by removing common endings
          const possibleRoot = cleanWord
            .replace(/(?:oj|aj|uj|ej|oj?n?|aj?n?|uj?n?|ej?n?|e|i|as|is|os|us|u)$/, '');
          
          if (possibleRoot.length >= 2) {
            roots.add(possibleRoot);
          }
        }
      }
    });

    // Ensure the utils directory exists
    const utilsDir = join(__dirname, '..', 'src', 'utils');
    try {
      await fs.mkdir(utilsDir, { recursive: true });
    } catch (err) {
      // Directory might already exist, which is fine
    }

    // Create the dictionary file content
    const dictionaryContent = `// Auto-generated from FrequencyWords GitHub repository
export const esperantoDictionary = new Set(${JSON.stringify([...dictionary], null, 2)});

export const esperantoRoots = new Set(${JSON.stringify([...roots], null, 2)});
`;

    // Write the dictionary file
    const outputPath = join(utilsDir, 'dictionary.ts');
    await fs.writeFile(outputPath, dictionaryContent, 'utf-8');
    
    console.log('Dictionary successfully created!');
    console.log(`Total words: ${dictionary.size}`);
    console.log(`Total roots: ${roots.size}`);
    
  } catch (error) {
    console.error('Error fetching dictionary:', error);
    process.exit(1);
  }
}

fetchAndProcessDictionary();