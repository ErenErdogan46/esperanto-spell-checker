import React, { useState, useCallback } from 'react';
import { BookOpen, AlertCircle, Keyboard } from 'lucide-react';
import { findSuggestions, convertXSystem } from './utils/esperantoUtils';

function App() {
  const [text, setText] = useState('');
  const [misspelledWords, setMisspelledWords] = useState<Map<string, string[]>>(new Map());

  const checkSpelling = useCallback((input: string) => {
    const words = input.split(/\s+/);
    const newMisspelledWords = new Map<string, string[]>();

    words.forEach(word => {
      const cleanWord = word.toLowerCase().replace(/[.,!?]/g, '');
      if (cleanWord) {
        const suggestions = findSuggestions(cleanWord);
        if (suggestions.length > 0) {
          newMisspelledWords.set(word, suggestions);
        }
      }
    });

    setMisspelledWords(newMisspelledWords);
  }, []);

  const handleTextChange = (e: React.ChangeEvent<HTMLTextAreaElement>) => {
    const newText = e.target.value;
    const convertedText = convertXSystem(newText);
    setText(convertedText);
    checkSpelling(convertedText);
  };

  return (
    <div className="min-h-screen bg-gradient-to-br from-green-50 to-emerald-100 p-8">
      <div className="max-w-2xl mx-auto">
        <div className="flex items-center justify-center mb-8">
          <BookOpen className="w-8 h-8 text-emerald-600 mr-3" />
          <h1 className="text-3xl font-bold text-emerald-800">
            Esperanto Spell Checker
          </h1>
        </div>

        <div className="bg-white rounded-lg shadow-lg p-6">
          <div className="mb-4 flex items-center text-sm text-emerald-600">
            <Keyboard className="w-4 h-4 mr-2" />
            <span>Type 'x' after c, g, h, j, s, u to get special characters (e.g., cx → ĉ)</span>
          </div>

          <textarea
            value={text}
            onChange={handleTextChange}
            className="w-full h-40 p-4 border border-emerald-200 rounded-lg focus:ring-2 focus:ring-emerald-500 focus:border-transparent resize-none"
            placeholder="Entajpu vian tekston ĉi tie... (Type your text here...)"
          />

          {misspelledWords.size > 0 && (
            <div className="mt-6">
              <h2 className="text-xl font-semibold text-emerald-800 mb-4 flex items-center">
                <AlertCircle className="w-5 h-5 mr-2 text-amber-500" />
                Spelling Suggestions
              </h2>
              <div className="space-y-3">
                {Array.from(misspelledWords).map(([word, suggestions]) => (
                  <div key={word} className="bg-amber-50 p-4 rounded-lg">
                    <span className="text-red-500 font-medium">{word}</span>
                    <div className="mt-2">
                      <span className="text-sm text-gray-600">Suggestions: </span>
                      {suggestions.map((suggestion, index) => (
                        <span key={suggestion} className="inline-block">
                          <span className="text-emerald-600 font-medium">{suggestion}</span>
                          {index < suggestions.length - 1 && <span className="mx-2">•</span>}
                        </span>
                      ))}
                    </div>
                  </div>
                ))}
              </div>
            </div>
          )}

          <div className="mt-6 text-sm text-gray-500">
            <p>This spell checker supports Esperanto word roots with common prefixes and suffixes. 
            For example, it recognizes words like "libroj" (books) and "malgranda" (small).</p>
          </div>
        </div>
      </div>
    </div>
  );
}

export default App;