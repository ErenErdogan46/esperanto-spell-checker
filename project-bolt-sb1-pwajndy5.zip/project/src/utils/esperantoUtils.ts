import { esperantoDictionary, esperantoRoots } from './dictionary';

// X-system conversion map
const xSystemMap: Record<string, string> = {
  'cx': 'ĉ',
  'gx': 'ĝ',
  'hx': 'ĥ',
  'jx': 'ĵ',
  'sx': 'ŝ',
  'ux': 'ŭ',
  'Cx': 'Ĉ',
  'Gx': 'Ĝ',
  'Hx': 'Ĥ',
  'Jx': 'Ĵ',
  'Sx': 'Ŝ',
  'Ux': 'Ŭ'
};

export function convertXSystem(text: string): string {
  let result = text;
  Object.entries(xSystemMap).forEach(([x, special]) => {
    result = result.replace(new RegExp(x, 'g'), special);
  });
  return result;
}

// Levenshtein Distance calculation for finding similar words
export function levenshteinDistance(a: string, b: string): number {
  const matrix = Array(b.length + 1).fill(null).map(() => Array(a.length + 1).fill(null));

  for (let i = 0; i <= a.length; i++) matrix[0][i] = i;
  for (let j = 0; j <= b.length; j++) matrix[j][0] = j;

  for (let j = 1; j <= b.length; j++) {
    for (let i = 1; i <= a.length; i++) {
      const substitutionCost = a[i - 1] === b[j - 1] ? 0 : 1;
      matrix[j][i] = Math.min(
        matrix[j][i - 1] + 1,
        matrix[j - 1][i] + 1,
        matrix[j - 1][i - 1] + substitutionCost
      );
    }
  }

  return matrix[b.length][a.length];
}

// Esperanto suffixes and endings
const grammaticalEndings = [
  '', // base form
  'o', // noun
  'oj', // plural noun
  'on', // accusative noun
  'ojn', // plural accusative noun
  'a', // adjective
  'aj', // plural adjective
  'an', // accusative adjective
  'ajn', // plural accusative adjective
  'e', // adverb
  'en', // accusative adverb
  'i', // infinitive verb
  'as', // present tense
  'is', // past tense
  'os', // future tense
  'us', // conditional
  'u', // imperative/volitive
];

// Common Esperanto prefixes
const commonPrefixes = [
  'mal', // opposite
  'ge', // both sexes
  'ek', // beginning of action
  're', // repetition
  'dis', // separation
  'sen', // without
];

function findWordRoot(word: string): string | null {
  // First check if the word exists in the dictionary
  if (esperantoDictionary.has(word.toLowerCase())) {
    return word.toLowerCase();
  }

  // Try removing common prefixes first
  let wordToCheck = word.toLowerCase();
  for (const prefix of commonPrefixes) {
    if (wordToCheck.startsWith(prefix)) {
      wordToCheck = wordToCheck.slice(prefix.length);
      break;
    }
  }

  // Try different possible roots by removing grammatical endings
  for (const ending of grammaticalEndings.sort((a, b) => b.length - a.length)) {
    if (wordToCheck.endsWith(ending)) {
      const possibleRoot = wordToCheck.slice(0, -ending.length);
      if (possibleRoot.length >= 2 && esperantoRoots.has(possibleRoot)) {
        return possibleRoot;
      }
    }
  }

  return null;
}

function isValidEsperantoWord(word: string): boolean {
  return findWordRoot(word) !== null || esperantoDictionary.has(word.toLowerCase());
}

export function findSuggestions(word: string): string[] {
  // First, check if it's actually a valid word with affixes
  if (isValidEsperantoWord(word)) {
    return [];
  }

  const suggestions: [string, number][] = [];
  const wordLower = word.toLowerCase();
  
  // Try to find similar words directly from the dictionary first
  esperantoDictionary.forEach(dictWord => {
    const distance = levenshteinDistance(wordLower, dictWord);
    if (distance <= 2) {
      suggestions.push([dictWord, distance]);
    }
  });

  // If we don't have enough suggestions, try with roots
  if (suggestions.length < 3) {
    esperantoRoots.forEach(root => {
      const distance = levenshteinDistance(wordLower, root);
      if (distance <= 2) {
        // Add suggestions with common endings
        for (const ending of grammaticalEndings) {
          const suggestion = root + ending;
          const finalDistance = levenshteinDistance(wordLower, suggestion);
          if (finalDistance <= 2) {
            suggestions.push([suggestion, finalDistance]);
          }
        }
      }
    });
  }

  return suggestions
    .sort((a, b) => a[1] - b[1])
    .map(([word]) => word)
    .filter((value, index, self) => self.indexOf(value) === index) // Remove duplicates
    .slice(0, 3); // Return top 3 suggestions
}